﻿#include <iostream>
#include "Listnum.h"
using namespace std;

int main()
{
    Listnum lst;
    lst.push_back(5);
    lst.push_back(10);
    lst.push_front(9);
    lst.insert(3, 1);
    lst.pop_front();
    cout << lst << endl;
    return 0;
}