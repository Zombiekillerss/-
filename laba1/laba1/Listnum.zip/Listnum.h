#pragma once
#include <iostream>
using namespace std;

class Listnum
{
public:
    Listnum();
    ~Listnum();
    void push_back(int newnumber);
    void push_front(int newnumber);
    void pop_back();
    void pop_front();
    void insert(int newnumber, size_t index);
    int get_elem(size_t index);
    void remove(size_t index);
    size_t get_size();
    void clear();
    void set(size_t index, int newnumber);
    bool isEmpty();
    void push_front(Listnum newlist);
    friend ostream& operator<< (ostream& out, const Listnum& list);
private:
    class Node
    {
    public:
        int number;
        class Node* next;
        Node(int newnumber = 0, Node* next = nullptr)
        {
            this->next = next;
            this->number= newnumber;
        }
        ~Node(){};
    };
    Node* head;
    int size;
};